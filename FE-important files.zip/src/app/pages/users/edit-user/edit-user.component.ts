// Path: src/app/pages/users/edit-user/edit-user.component.ts
// ──────────────────────────────────────────────────────────────────────────────
// Angular core / common
// ──────────────────────────────────────────────────────────────────────────────
import {
  AsyncPipe,
  CommonModule,
  isPlatformBrowser,
} from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';
import {
  AfterViewInit,
  Component,
  ElementRef,
  HostListener,
  Inject,
  OnDestroy,
  OnInit,
  PLATFORM_ID,
  ViewChild,
} from '@angular/core';

// ──────────────────────────────────────────────────────────────────────────────
// Forms / Material
// ──────────────────────────────────────────────────────────────────────────────
import {
  FormControl,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatAutocompleteModule, type MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule, MatIconRegistry } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSelectModule } from '@angular/material/select';

// ──────────────────────────────────────────────────────────────────────────────
// Angular router / platform
// ──────────────────────────────────────────────────────────────────────────────
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';

// ──────────────────────────────────────────────────────────────────────────────
// Third-party components
// ──────────────────────────────────────────────────────────────────────────────
import { EditorComponent } from '@tinymce/tinymce-angular';
import {
  ImageCroppedEvent,
  ImageCropperComponent,
} from 'ngx-image-cropper';

// ──────────────────────────────────────────────────────────────────────────────
// RxJS
// ──────────────────────────────────────────────────────────────────────────────
import { Observable, of, Subscription } from 'rxjs';
import { map, startWith } from 'rxjs/operators';

// ──────────────────────────────────────────────────────────────────────────────
// Shared components / dialogs
// ──────────────────────────────────────────────────────────────────────────────
import { CameraBoxComponent } from '../../../components/dialogs/camera-box/camera-box.component';
import {
  NotificationDialogComponent
} from '../../../components/dialogs/notificationBar/notificationBar.component';
import { ProgressBarComponent } from '../../../components/dialogs/progress-bar/progress-bar.component';
import { TextEditorComponent } from '../../../components/shared/textEditor/text-editor';

// ──────────────────────────────────────────────────────────────────────────────
// Services and types
// ──────────────────────────────────────────────────────────────────────────────
import {
  APIsService,
  Country,
  DEFAULT_ROLES,
  PermissionEntry,
  Role,
  ROLE_ACCESS_MAP,
  type CountryCodes,
  type MultiAuthData,
  type User,
} from '../../../services/APIs/apis.service';
import {
  AuthService
} from '../../../services/auth/auth.service';
import { CryptoService } from '../../../services/cryptoService/crypto.service';
import { ImageService } from '../../../services/imageService/image.service';
import { UserControllerService } from '../../../services/userController/user-controller.service';
import { WindowsRefService } from '../../../services/windowRef/windowRef.service';
import {
  ACCESS_OPTIONS,
  AccessActionKey,
  AccessModuleKey,
  AccessModuleOption,
} from '../../../source/access-map.source';
import { SwitchButton } from '../../../components/shared/buttons/switch-button/switch-button.component';
import { MultiAuthQrCodeDialogComponent } from '../../../components/dialogs/multi-auth-qr-code/multi-auth-qr-code.component';
import { MatDialog } from '@angular/material/dialog';
import type { MultiAuthDialogResult } from '../../../types/common';

// ──────────────────────────────────────────────────────────────────────────────
// Local interfaces
// ──────────────────────────────────────────────────────────────────────────────


interface userActiveStatusType {
  typeName: string;
  isActive: boolean;
}

interface MODEL_CHECK {
  model: string;
  check: boolean;
  action: string;
}

// ──────────────────────────────────────────────────────────────────────────────
// Component
// ──────────────────────────────────────────────────────────────────────────────
@Component( {
  selector: 'app-edit-user',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    // Material
    MatInputModule,
    MatFormFieldModule,
    MatButtonModule,
    MatIconModule,
    MatCheckboxModule,
    MatAutocompleteModule,
    AsyncPipe,
    MatDatepickerModule,
    MatMomentDateModule,
    MatSelectModule,
    MatDividerModule,
    MatDialogModule,
    MatProgressBarModule,
    // App components
    NotificationDialogComponent,
    ProgressBarComponent,
    ImageCropperComponent,
    CameraBoxComponent,
    TextEditorComponent,
    SwitchButton,
  ],
  templateUrl: './edit-user.component.html',
  styleUrl: './edit-user.component.scss',
} )
export class EditUserComponent
  implements OnInit, OnDestroy, AfterViewInit {

  // ──────────────────────────────────────────────────────────────────────────
  // ViewChild references
  // ──────────────────────────────────────────────────────────────────────────
  @ViewChild( 'fileInput' )
  fileInput!: ElementRef<HTMLInputElement>;

  @ViewChild( ProgressBarComponent )
  progress!: ProgressBarComponent;

  @ViewChild( NotificationDialogComponent )
  notification!: NotificationDialogComponent;

  @ViewChild( ImageCropperComponent )
  imageCropper!: ImageCropperComponent;

  @ViewChild( CameraBoxComponent )
  cameraBox!: CameraBoxComponent;

  // ──────────────────────────────────────────────────────────────────────────
  // Theme / platform
  // ──────────────────────────────────────────────────────────────────────────
  protected mode: boolean | null = null;
  protected isBrowser: boolean;
  private modeSub: Subscription | null = null;

  // ──────────────────────────────────────────────────────────────────────────
  // User + token state
  // ──────────────────────────────────────────────────────────────────────────
  protected user: User | null = null;
  private token!: string;
  protected isLoading: boolean = true;

  private loggedUser: User | null = null;
  private creator: string = '';
  private updator: string = '';

  // ──────────────────────────────────────────────────────────────────────────
  // Images
  // ──────────────────────────────────────────────────────────────────────────
  protected readonly definedMaleDummyImageURL: string =
    'Images/user-images/dummy-user/dummy-user.jpg';
  protected readonly definedWomanDummyImageURL: string =
    'Images/user-images/dummy-user/dummy_woman.jpg';
  protected definedImage: string =
    'Images/user-images/dummy-user/dummy-user.jpg';

  protected readonly definedImageExtentionArray: string[] = [
    'jpg',
    'webp',
    'jpeg',
    'png',
    'ico',
    'gif',
  ];

  protected userUploadedImage: string = '';
  protected userimage: File | null = null;
  protected userExistedImage: string = '';

  // Cropper state
  protected selectedImageChangedEvent: any = null;
  protected croppedImageBase64: string = '';
  protected showCropper: boolean = false;
  protected croppedImage: any = '';
  protected isDragOver: boolean = false;
  protected isCameraOpen: boolean = false;

  // TinyMCE init
  init: EditorComponent[ 'init' ] = {
    plugins: 'lists link image table code help wordcount',
  };

  // ──────────────────────────────────────────────────────────────────────────
  // List / paging (kept for compatibility if template uses them)
  // ──────────────────────────────────────────────────────────────────────────
  protected users: User[] = [];
  protected pageCount: number = 0;
  protected currentPage: number = 0;
  protected search: string = '';
  protected loading: boolean = true;

  // ──────────────────────────────────────────────────────────────────────────
  // Country / autocomplete
  // ──────────────────────────────────────────────────────────────────────────
  protected countryControl = new FormControl<string>( '' );
  protected countries: Country[] = [];
  protected filteredCountries!: Observable<Country[]>;
  protected typedCountry: Country | string | null = '';

  // ──────────────────────────────────────────────────────────────────────────
  // Validation patterns / state
  // ──────────────────────────────────────────────────────────────────────────
  protected isValidAge: boolean = false;
  protected isUsernameExist: boolean = false;
  protected hidePassword: boolean = true;

  private readonly strongPasswordPattern: RegExp =
    /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_])[A-Za-z\d\W_]{8,}$/;
  private readonly usernamePattern: RegExp = /^[a-zA-Z0-9._-]{4,20}$/;
  private readonly emailPattern: RegExp =
    /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  private readonly phonePattern: RegExp =
    /^\+?[0-9\s\-()]{10,15}$/; // reserved

  protected usernameMatchPattern: boolean = true;
  protected passwordMatchPattern: boolean = true;
  protected isEmailError: boolean = false;
  protected emailErrorMessage: string = '';
  protected isPhoneError: boolean = false;
  protected phoneErrorMessage: string = '';

  // ──────────────────────────────────────────────────────────────────────────
  // User data fields
  // ──────────────────────────────────────────────────────────────────────────
  protected username: string = '';
  protected password: string = '';
  protected fullname: string = '';
  protected email: string = '';
  private oldEmail: string = '';
  protected phone: string = '';
  protected phoneCode: CountryCodes | null = null;
  private phoneNumber: User[ 'phoneNumber' ] | null = null;
  protected street: string = '';
  protected houseNumber: string = '';
  protected city: string = '';
  protected postcode: string = '';
  protected stateOrProvince: string = '';
  protected role: string = '';
  private _isMultiAuthActive: boolean = false;

  protected age: number = 0;
  protected dateOfBirth: Date = new Date();
  protected isActive: boolean = false;
  protected updatedAt: Date = new Date();
  protected createdAt: Date = new Date();
  protected userGender: string = '';
  protected userBio: string = '';
  protected nationality: string = '';
  protected nicOrPassport: string = '';

  protected modelCheck: MODEL_CHECK = {
    model: '',
    check: false,
    action: '',
  };

  // ──────────────────────────────────────────────────────────────────────────
  // Access / roles
  // ──────────────────────────────────────────────────────────────────────────

  /** Full access catalogue used by the template */
  protected readonly accessOptions: ReadonlyArray<AccessModuleOption> = ACCESS_OPTIONS;

  /** Canonical permission catalogue – used for lookups (never mutated) */
  protected readonly allPermissionAccesses: ReadonlyArray<AccessModuleOption> = ACCESS_OPTIONS;

  /**
   * Current selection of access for the chosen role.
   * This is the ONLY source of truth we will send to backend.
   */
  private originalSelectionOfAccess: ROLE_ACCESS_MAP | null = null;

  // defined roles
  protected readonly definedRole: Role[] = [
    'admin',
    'agent',
    'tenant',
    'owner',
    'operator',
    'manager',
    'developer',
    'user',
  ];

  // User status choices
  protected readonly userActiveStatus: userActiveStatusType[] = [
    { typeName: 'Active', isActive: true },
    { typeName: 'Inactive', isActive: false },
  ];

  // Genders
  protected readonly definedGender: string[] = [
    'Male',
    'Female',
    'Other',
  ];

  protected phoneCodes: CountryCodes[] = [];
  protected filterPhoneCodes: Observable<CountryCodes[]> | null = null;

  private navigationTimeoutId: number | null = null;


  // ──────────────────────────────────────────────────────────────────────────
  // Constructor
  // ──────────────────────────────────────────────────────────────────────────
  constructor (
    private readonly windowRef: WindowsRefService,
    @Inject( PLATFORM_ID ) private readonly platformId: Object,
    private readonly activatedRouter: ActivatedRoute,
    private readonly router: Router,
    private readonly apiService: APIsService,
    private readonly crypto: CryptoService,
    private readonly matIconRegistry: MatIconRegistry,
    private readonly domSanitizer: DomSanitizer,
    private readonly authService: AuthService,
    private readonly userControlService: UserControllerService,
    private readonly imageService: ImageService,
    private readonly dialog: MatDialog,
  ) {
    this.isBrowser = isPlatformBrowser( this.platformId );
    this.activatedRouter.url.subscribe( () => {
      // reserved for future
    } );
    this.registerIcons();

    this.loggedUser = this.authService.getLoggedUser;
    this.updator = this.loggedUser ? this.loggedUser.username : '';

    this.activatedRouter.params.subscribe( async ( param ): Promise<void> => {
      this.token = param[ 'token' ];
      await this.loadData();
    } );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Lifecycle hooks
  // ──────────────────────────────────────────────────────────────────────────
  async ngOnInit(): Promise<void> {
    if ( this.isBrowser ) {
      // Prevent default drag/drop behavior globally
      window.addEventListener( 'dragover', this.preventDefault, {
        passive: false,
      } );
      window.addEventListener( 'drop', this.preventDefault, {
        passive: false,
      } );

      this.modeSub = this.windowRef.mode$.subscribe(
        ( val ) => ( this.mode = val ),
      );

      await this.getCountryCodes();
      await this.loadAllCountries();
    }
  }

  ngAfterViewInit(): void {
    // View children ready
  }

  ngOnDestroy(): void {
    if ( this.isBrowser ) {
      window.removeEventListener( 'dragover', this.preventDefault );
      window.removeEventListener( 'drop', this.preventDefault );
    }

    if ( this.navigationTimeoutId !== null ) {
      window.clearTimeout( this.navigationTimeoutId );
      this.navigationTimeoutId = null;
    }

    this.modeSub?.unsubscribe();
  }


  // ──────────────────────────────────────────────────────────────────────────
  // Filter user image
  // ──────────────────────────────────────────────────────────────────────────
  protected filterUserImage() {
    const userImage = this.user?.image ?? '';
    const metaData = this.imageService.getImageMetadataFromUrl( userImage as string );
    console.log( metaData );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Shared helper: error notification
  // ──────────────────────────────────────────────────────────────────────────
  private notifyError( error: unknown, fallbackMessage: string ): void {
    console.error( error );

    if ( error instanceof HttpErrorResponse ) {
      const msg = error.error?.message ?? error.message;
      this.notification?.notification( 'error', msg );
      return;
    }

    if ( typeof error === 'string' ) {
      this.notification?.notification( 'error', error );
      return;
    }

    if ( error instanceof Error ) {
      this.notification?.notification( 'error', error.message );
      return;
    }

    this.notification?.notification( 'error', fallbackMessage );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Icon registration
  // ──────────────────────────────────────────────────────────────────────────
  private registerIcons(): void {
    const icons = [
      { name: 'camera', path: 'Images/Icons/camera.svg' },
      { name: 'upload', path: 'Images/Icons/upload.svg' },
      { name: 'insert', path: 'Images/Icons/user-plus.svg' },
    ];

    for ( const icon of icons ) {
      this.matIconRegistry.addSvgIcon(
        icon.name,
        this.domSanitizer.bypassSecurityTrustResourceUrl( icon.path ),
      );
    }
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Gender & dummy images
  // ──────────────────────────────────────────────────────────────────────────
  protected detectGender( value: string ): void {
    if ( value === 'Male' ) {
      this.definedImage = this.definedMaleDummyImageURL;
    } else if ( value === 'Female' ) {
      this.definedImage = this.definedWomanDummyImageURL;
    } else {
      this.definedImage = this.definedMaleDummyImageURL;
    }
  }

  protected detectUserImage( image: string | File, gender: string | undefined ): string {
    if ( !gender ) return this.definedMaleDummyImageURL;
    if ( typeof image !== 'string' ) return this.definedMaleDummyImageURL;
    const imageArray: string[] = image ? image.split( '/' ) : [];
    if ( imageArray.length > 0 ) {
      const lastSegment = imageArray[ imageArray.length - 1 ];
      const ext = lastSegment.split( '.' )[ 1 ];
      if ( ext && this.definedImageExtentionArray.includes( ext ) ) {
        return image;
      }
    }
    return gender.toLowerCase() === 'male'
      ? this.definedMaleDummyImageURL
      : this.definedWomanDummyImageURL;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Accessor for template
  // ──────────────────────────────────────────────────────────────────────────
  get userData(): User | null {
    return this.user ?? null;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Multi-Auth activation
  // ──────────────────────────────────────────────────────────────────────────
  get isMultiAuthActive(): boolean {
    return this._isMultiAuthActive;
  }
  set isMultiAuthActive( value: boolean ) {
    this._isMultiAuthActive = value;
    if ( this._isMultiAuthActive ) {
      void this.openMulltiAuthDialog();
    }
    else {
      void this.deactiveMultiAuth();
    }
  }

  private openMulltiAuthDialog(): void {
    try {
      if ( !this.user ) {
        throw new Error( 'Invalid user' );
      }

      const dialogRef = this.dialog.open( MultiAuthQrCodeDialogComponent, {
        maxWidth: 700,
        maxHeight: 700,
        minWidth: 200,
        minHeight: 200,
        disableClose: true,
        data: {
          username: this.user.username,
        }
      } );

      dialogRef.afterClosed().subscribe( ( result: MultiAuthDialogResult ): void => {
        if ( !result ) {
          return;
        }

        if ( result.success ) {
          // ✅ MFA is active now
          console.log( 'MFA activated with reason:', result.reason, 'data:', result.authData );
          // update UI / state
        } else {
          console.log( 'MFA not activated. Reason:', result.reason );
        }
      } );
    }
    catch ( error ) {
      console.error( error );
      let fallbackMessage = 'Unexpected error ocured!';
      this.notifyError( error, fallbackMessage );
    }
  }

  private async deactiveMultiAuth(): Promise<void> {
    try {
      if ( !this.user ) {
        throw new Error( 'Invalid user!' );
      }

      const username = this.user.username;

      if ( !username ) {
        throw new Error( 'Invalid username!' );
      }

      const res = await this.apiService.deactiveMultiAuth( username );

      if ( !res.success ) {
        throw new Error( res.message ?? 'Failed to deactive multi auth!' );
      }

      this.notification.notification( 'success', 'Multi-authentication desabled successful!' );
    }
    catch ( error ) {
      console.error( error );
      const fallbackMessage = 'Unexpected error!';
      this.notifyError( error, fallbackMessage );
    }
  }
  // ──────────────────────────────────────────────────────────────────────────
  // Load user data by token
  // ──────────────────────────────────────────────────────────────────────────
  private async loadData(): Promise<void> {
    try {
      if ( !this.token ) throw new Error( 'Invalid user token' );

      const res = await this.apiService.getUserByToken( this.token );

      if ( !res.success || res.status !== 'success' ) {
        throw new Error( 'Failed to fetch user data from token' );
      }

      const user = res.data?.system?.user;
      if ( !user ) {
        throw new Error( 'Invalid user data!' );
      }

      this.user = user;

      this.assignValues();
    } catch ( err ) {
      console.error( err );
      this.notification.notification(
        'error',
        'Loading user data failed!',
      );
      setTimeout( () => {
        this.router.navigate( [ '/dashboard/unauthorized' ] );
      }, 500 );
    }
  }

  private assignValues(): void {
    try {
      if ( !this.user ) throw new Error( 'Invalid user!' );

      // basic
      this.fullname = this.user.name;
      this.userGender =
        this.user.gender.charAt( 0 ).toUpperCase() +
        this.user.gender.slice( 1 );
      this.detectGender( this.userGender );

      this.username = this.user.username;
      this.email = this.user.email;
      this.oldEmail = this.user.email;
      this.phone = this.user.phoneNumber?.number ?? '';
      this.phoneCode = this.user.phoneNumber?.code ?? null;
      this.phoneNumber = this.user.phoneNumber;

      this.dateOfBirth = new Date( this.user.dateOfBirth ?? '' );
      this.age = this.user.age;
      this.isValidAge = this.user.age >= 18;

      this.isActive = this.user.isActive;
      this.role = this.user.role;
      this.userBio = this.user.bio;
      this.nationality = this.user.nationality;
      this.nicOrPassport = this.user.nicOrPassport;

      this.updatedAt = new Date( this.user.updatedAt ?? '' );
      this.createdAt = new Date( this.user.createdAt ?? '' );
      this.creator = this.user.creator ?? '';
      this.updator = this.user.updator ?? this.updator;

      // address
      this.houseNumber = this.user.address.houseNumber;
      this.street = this.user.address.street ?? '';
      this.city = this.user.address.city;
      this.stateOrProvince = this.user.address.stateOrProvince ?? '';
      this.postcode = this.user.address.postcode;

      const country = this.user.address.country ?? '';
      this.countryControl.setValue( country );
      this.typedCountry = country;
      this.onCountryChange( country );

      // access
      this.originalSelectionOfAccess = this.user.access;


      this.normalizeExistingAccess();

      // image
      this.userExistedImage = this.user.image as string;

      // Multi-auth status
      this._isMultiAuthActive = this.user.multiAuthEnabled;

      setTimeout( () => {
        this.isLoading = false;
      }, 500 );
    } catch ( err ) {
      console.error( err );
      this.notification.notification( 'error', 'Invalid user data!' );
    }
  }

  private async getCountryCodes(): Promise<void> {
    try {
      const res = await this.apiService.getCountryCodes();
      this.phoneCodes = res;
    } catch ( err ) {
      console.error( err );
      this.notification.notification(
        'error',
        'Failed to load country codes.',
      );
    }
  }

  protected whilePhoneCodeChange( text: string ): void {
    try {
      // Reset filter
      this.filterPhoneCodes = of( this.phoneCodes );
      // Sanitising the input
      const safeInput = ( typeof text === 'string' && text.trim().toLowerCase() )
        || ( typeof text === 'object' && 'code' in text
          ? ( text as CountryCodes ).code.toLowerCase()
          : '' );
      // Filtering based on tenant type
      this.filterPhoneCodes = of(
        this.phoneCodes.filter( ( item ) =>
          item.code.toLowerCase().includes( safeInput ),
        ),
      );
    }
    catch ( error ) {
      console.error( error );
      return;
    }
  }

  protected onPhoneCodeSelectionChange(
    input: MatAutocompleteSelectedEvent, type: string,
  ): void {
    const value = input.option.value as CountryCodes;
    this.phoneCode = value;
  }

  protected displayPhoneCode(
    country: string | { code: string; } | null | undefined
  ): string {
    if ( !country ) return '';

    if ( typeof country === 'string' ) {
      return country.trim();
    }

    if ( 'code' in country ) {
      return country.code ?? '';
    }

    return '';
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Camera capture → File
  // ──────────────────────────────────────────────────────────────────────────
  protected openCamera(): void {
    this.isCameraOpen = true;
  }

  protected closeCamera(): void {
    this.isCameraOpen = false;
  }

  protected handleImage( imageData: string ): void {
    this.userUploadedImage = imageData;
    this.userimage = this.convertToBlob( imageData );
    this.isCameraOpen = false;

    const file = this.convertToBlob( imageData );
    const dt = new DataTransfer();
    dt.items.add( file );

    const simulatedEvent = {
      target: {
        files: dt.files,
      },
    };

    this.onFileSelected( simulatedEvent );
  }

  protected convertToBlob( data: string ): File {
    const byteString = atob( data.split( ',' )[ 1 ] );
    const byteArray = new Uint8Array( byteString.length );
    for ( let i = 0; i < byteString.length; i++ ) {
      byteArray[ i ] = byteString.charCodeAt( i );
    }
    const blob = new Blob( [ byteArray ], { type: 'image/png' } );
    return new File( [ blob ], 'image.png', { type: 'image/png' } );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Paste image handler
  // ──────────────────────────────────────────────────────────────────────────
  @HostListener( 'document:paste', [ '$event' ] )
  protected handlePaste( event: ClipboardEvent ): void {
    const target = event.target as HTMLElement;

    // allow normal paste in inputs / editable fields
    if (
      target.tagName === 'INPUT' ||
      target.tagName === 'TEXTAREA' ||
      target.hasAttribute( 'contenteditable' )
    ) {
      return;
    }

    event.preventDefault();

    const items = event.clipboardData?.items;
    if ( !items ) return;

    for ( const item of items ) {
      if ( item.kind === 'file' ) {
        const file = item.getAsFile();
        if ( file ) {
          this.processPastedFile( file );
        }
      }
    }
  }

  protected processPastedFile( file: File ): void {
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add( file );

    const input = this.fileInput.nativeElement;
    input.files = dataTransfer.files;

    this.onFileSelected( { target: input } as any );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Drag & drop image
  // ──────────────────────────────────────────────────────────────────────────
  protected onDragOver( event: DragEvent ): void {
    event.preventDefault();
    this.isDragOver = true;
  }

  protected onDragLeave( event: DragEvent ): void {
    event.preventDefault();
    this.isDragOver = false;
  }

  protected onDrop( event: DragEvent ): void {
    event.preventDefault();
    this.isDragOver = false;

    const files = event.dataTransfer?.files;
    if ( files && files.length > 0 ) {
      const file = files[ 0 ];
      if ( file.type.startsWith( 'image/' ) ) {
        this.processDroppedFile( file );
      }
    }
  }

  protected processDroppedFile( file: File ): void {
    const dataTransfer = new DataTransfer();
    dataTransfer.items.add( file );

    const input = this.fileInput.nativeElement;
    input.files = dataTransfer.files;

    this.onFileSelected( { target: input } as any );
  }

  private preventDefault( event: Event ): void {
    event.preventDefault();
    event.stopPropagation();
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Image upload + cropper
  // ──────────────────────────────────────────────────────────────────────────
  protected triggerFileInput(): void {
    if ( this.fileInput?.nativeElement ) {
      this.fileInput.nativeElement.click();
    }
  }

  protected onFileSelected( event: any ): void {
    this.selectedImageChangedEvent = event;
    this.showCropper = true;
  }

  protected imageCropped( event: ImageCroppedEvent ): void {
    this.croppedImageBase64 = event.objectUrl as string;
    this.croppedImage = event;
  }

  protected saveCroppedImage(): void {
    this.userUploadedImage = this.croppedImageBase64;
    this.detectUserImage( this.userUploadedImage, this.userGender );
    this.userimage = this.croppedImage.blob;
    this.showCropper = false;
    this.resetCropper();
  }

  protected cancelCrop(): void {
    this.userUploadedImage = '';
    this.userimage = null;
    this.resetCropper();
  }

  private resetCropper(): void {
    this.selectedImageChangedEvent = null;
    this.croppedImageBase64 = '';
    this.showCropper = false;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Page indicators
  // ──────────────────────────────────────────────────────────────────────────
  protected goToUsers(): void {
    this.router
      .navigateByUrl( '/', { skipLocationChange: true } )
      .then( () => this.router.navigate( [ '/dashboard/users' ] ) )
      .catch( ( err ) =>
        this.notifyError( err, 'Failed to navigate to users page.' ),
      );
  }

  protected async goToUser(): Promise<void> {
    this.router
      .navigateByUrl( '/', { skipLocationChange: true } )
      .then( () =>
        this.router.navigate( [ '/dashboard/add-new-user' ] ),
      )
      .catch( ( err ) =>
        this.notifyError(
          err,
          'Failed to navigate to add new user page.',
        ),
      );
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Age / DOB
  // ──────────────────────────────────────────────────────────────────────────
  protected checkAge( value: string | number ): void {
    const age = Number( value );
    this.age = age;
    this.isValidAge = age >= 18;
  }

  protected validateDateOfBirth( value: Date | string ): void {
    if ( !value ) {
      this.isValidAge = false;
      this.age = 0;
      return;
    }

    const dateOfBirth = new Date( value );
    const today = new Date();

    let age = today.getFullYear() - dateOfBirth.getFullYear();
    const monthDiff = today.getMonth() - dateOfBirth.getMonth();
    const dayDiff = today.getDate() - dateOfBirth.getDate();

    if ( monthDiff < 0 || ( monthDiff === 0 && dayDiff < 0 ) ) {
      age--;
    }

    this.age = age;
    this.isValidAge = age >= 18;
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Country selector
  // ──────────────────────────────────────────────────────────────────────────

  private async loadAllCountries(): Promise<void> {
    try {
      const countries = await this.apiService.getCountries();


      if ( !Array.isArray( countries ) ) {
        throw new Error( 'Invalid array of countries!' );
      };

      this.countries = countries;
    }
    catch ( error ) {
      console.error( error );
    }
  }
  protected onCountryChange( value: string ): void {
    this.typedCountry = value;
    this.mainFilterCountries();
  }

  private mainFilterCountries(): Country[] {
    this.filteredCountries = this.countryControl.valueChanges.pipe(
      startWith( this.typedCountry ),
      map( ( value: string | Country | null ) => {
        const name = typeof value === 'string' ? value : value?.name;
        return name
          ? this.filterCountries( name )
          : this.countries.slice();
      } ),
    );

    return this.countries;
  }

  private filterCountries( name: string ): Country[] {
    const filterValue = name.toLowerCase();
    return this.countries.filter( ( c ) =>
      c.name.toLowerCase().includes( filterValue ),
    );
  }

  protected displayFn( country: Country | string | null ): string {
    if ( typeof country === 'string' ) return country;
    return country?.name ?? '';
  }

  // ──────────────────────────────────────────────────────────────────────────
  // Username / password / email / phone checks
  // ──────────────────────────────────────────────────────────────────────────
  protected async checkUsername( event: Event ): Promise<void> {
    try {
      const input = event.target as HTMLInputElement;
      const value = input.value.trim();

      this.usernameMatchPattern = this.usernamePattern.test( value );

      if ( !this.usernameMatchPattern ) {
        this.notification.notification( 'warning', 'Invalid username pattern!' );
        return; // early exit – don’t call API for invalid pattern
      }

      const res = await this.apiService.getUserByUsername( value );
      if ( res.status !== 'success' ) {
        throw new Error( 'Failed to fetch validation!' );
      }

      const user = res.data?.system?.user as User | undefined;

      // If found user is the same one we're editing → no conflict
      if ( user && this.user && user.username !== this.user.username ) {
        this.notification.notification( 'error', 'Username already existed!' );
        this.isUsernameExist = true;
      } else {
        this.isUsernameExist = false;
      }
    } catch ( error ) {
      console.error( error );
    }
  }


  protected checkPassword( event: Event ): void {
    const input = event.target as HTMLInputElement;
    const password = input.value;
    this.passwordMatchPattern = this.strongPasswordPattern.test(
      password,
    );
  }

  protected async checkEmail( input: string ): Promise<void> {
    try {
      if ( !this.emailPattern.test( input ) ) {
        this.isEmailError = true;
        this.emailErrorMessage = 'Invalid email format';
        return;
      }

      const checking: boolean = await this.emailValidator(
        input.trim(),
        'User',
      );

      if ( !checking ) {
        this.isEmailError = true;
        this.emailErrorMessage = 'Invalid email';
        throw new Error( 'Invalid email' );
      }

      this.isEmailError = !checking;
      this.emailErrorMessage = !checking ? 'Invalid email' : 'Valid email';

      const res = await this.apiService.getUserByEmail( input );

      if ( res.status !== 'success' ) {
        throw new Error( 'Failed to confirm is the email exist!' );
      }

      const user: User | undefined = res.data?.system?.user;
      const other = this.apiService.extractObjectFromOther<{ status: boolean; }>(
        res.data,
        'other',
      );
      const status = other?.status;

      // If some user exists AND it is not the current edited user → conflict
      if ( user && status && ( !this.user || user.username !== this.user.username ) ) {
        this.isEmailError = true;
        this.emailErrorMessage = 'Email already exists';
        throw new Error( 'Email already exists' );
      }

      this.isEmailError = false;
      this.emailErrorMessage = '';
    } catch ( error ) {
      console.error( error );
      if ( error instanceof HttpErrorResponse ) {
        this.notification.notification(
          'error',
          error.error.message,
        );
      } else {
        this.notification.notification( 'error', error as string );
      }
    }
  }

  private async emailValidator( email: string, userLabel: string ): Promise<boolean> {
    try {
      const safeEmail = email.trim();
      const safeUser = userLabel.trim();

      if ( !safeEmail ) {
        throw new Error( 'Email is required.' );
      }

      if ( !safeUser ) {
        throw new Error( 'User label is required.' );
      }

      // 1) Basic local format validation
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if ( !emailRegex.test( safeEmail ) ) {
        throw new Error( 'Invalid email format.' );
      }

      // 2) Call backend / external validator
      const res = await this.userControlService.emailValidator( safeEmail );

      if ( !res || res.status !== 'success' ) {
        const msg = `Failed to validate email of ${ safeUser }.`;
        throw new Error( msg );
      }

      // 3) Extract fields from `other` (using your helpers)
      const validatedEmail = this.apiService.extractStringFromOther(
        res.data,
        'email',
      );

      const validationObj =
        this.apiService.extractObjectFromOther<{
          format: boolean;
          mx: boolean;
        }>( res.data, 'validation' );

      const domain = this.apiService.extractStringFromOther(
        res.data,
        'domain',
      );

      if ( !validatedEmail ) {
        throw new Error( 'Email provider returned an invalid email.' );
      }

      if ( !domain ) {
        throw new Error( 'Email provider returned an invalid domain.' );
      }

      if ( !validationObj?.format || !validationObj.mx ) {
        throw new Error( `Please enter a valid email address for ${ safeUser }.` );
      }

      // All good
      return true;

    } catch ( error ) {
      console.error( error );

      let message = 'Unexpected error while validating email.';

      // Order matters if you use HttpErrorResponse
      if ( error instanceof HttpErrorResponse ) {
        message = error.error?.message || message;
      } else if ( error instanceof Error ) {
        message = error.message || message;
      }

      // Simple severity mapping (optional)
      const level: 'warning' | 'error' =
        message.toLowerCase().includes( 'format' ) ? 'warning' : 'error';

      this.notification.notification( level, message );

      return false;
    }
  }


  protected async checkPhone( input: string ): Promise<void> {
    // reset state before validation
    this.isPhoneError = false;
    this.phoneErrorMessage = '';

    try {
      if ( !this.user ) {
        throw new Error( 'Invalid user context!' );
      }

      const safeInput = input.trim();
      if ( !safeInput ) {
        throw new Error( 'Phone number is required.' );
      }

      if ( !this.phoneCode?.code ) {
        throw new Error( 'Please select a country code.' );
      }

      const fullPhoneNumber: User[ 'phoneNumber' ] = {
        code: this.phoneCode,
        number: safeInput,
      };
      const currentUsername = this.user.username;

      // 1) Local format validation
      const isValidFormat = await this.userControlService.isPhoneNumberValid( fullPhoneNumber );
      if ( !isValidFormat ) {
        throw new Error( 'Invalid phone number.' );
      }

      // 2) Backend uniqueness check
      const res = await this.apiService.getUserByPhone( fullPhoneNumber );

      // If API call itself failed in a "soft" way (no thrown HttpErrorResponse)
      if ( !res.success ) {
        // Adjust these lines depending on your MSG interface
        const msg = res.message || 'Failed to validate phone number.';
        throw new Error( msg );
      }

      // success === true here
      const existingUser = res.data?.system?.user;

      // Case: phone not in use → OK
      if ( !existingUser ) {
        return;
      }

      // Case: phone belongs to *another* user → reject
      if ( existingUser.username !== currentUsername ) {
        throw new Error( 'Phone number belongs to another user!' );
      }

      // Case: phone belongs to current user → OK, no error flags
      return;

    } catch ( error ) {
      console.error( error );

      let message = 'Unexpected error while validating phone number.';

      // Order matters: HttpErrorResponse extends Error
      if ( error instanceof HttpErrorResponse ) {
        if ( error.status === 404 ) {
          return;
        }
        message = error.error?.message || message;
      } else if ( error instanceof Error ) {
        message = error.message || message;
      }

      this.isPhoneError = true;
      this.phoneErrorMessage = message;
      this.notification.notification( 'error', message );
    }
  }


  // ──────────────────────────────────────────────────────────────────────────
  // Role access helpers: role change, module toggle, action toggle
  // ──────────────────────────────────────────────────────────────────────────

  private normalizeExistingAccess(): void {
    if ( !this.originalSelectionOfAccess ) return;

    const safeRole = this.role as Role;
    const normalized: PermissionEntry[] = [];

    for ( const perm of this.originalSelectionOfAccess.permissions ) {
      // Find the canonical module definition
      const moduleDef = this.allPermissionAccesses.find(
        ( m ) => m.module.toLowerCase() === perm.module.toLowerCase(),
      );
      if ( !moduleDef ) continue;

      const actionIds: string[] = [];

      // For each stored action string, match it either by id or label
      for ( const stored of perm.actions ) {
        const found = moduleDef.actions.find(
          ( opt ) =>
            opt.id.toLowerCase() === stored.toLowerCase() ||
            opt.label.toLowerCase() === stored.toLowerCase(),
        );

        if ( !found ) {
          continue;
        }

        // avoid duplicates
        if ( !actionIds.includes( found.id ) ) {
          actionIds.push( found.id );
        }
      }

      if ( actionIds.length > 0 ) {
        normalized.push( {
          module: moduleDef.module as AccessModuleKey,
          actions: actionIds as AccessActionKey[],
        } );
      }
    }

    this.originalSelectionOfAccess = {
      role: safeRole,
      permissions: normalized,
    };
  }


  /**
   * 1) When role changes:
   *    - validate role
   *    - get default access map from AuthService
   *    - build ROLE_ACCESS_MAP (all default actions pre-selected)
   */
  protected whileRoleChange( role: Role ): void {
    try {
      // Keep selected role in component state
      this.role = role;

      // Validate role against DEFAULT_ROLES (array, so use includes)
      if ( !role || !DEFAULT_ROLES.includes( role ) ) {
        this.notification.notification( 'warning', 'Invalid role selection!' );
        this.originalSelectionOfAccess = null;
        return;
      }

      // Default modules for this role
      const defaultModules: ReadonlyArray<AccessModuleOption> =
        this.authService.filterDefaultAccessBaseRole( role );

      // Build canonical ROLE_ACCESS_MAP using ONLY ids from access map
      const permissions: PermissionEntry[] = defaultModules.map(
        ( mod ): PermissionEntry => ( {
          module: mod.module as AccessModuleKey,
          actions: mod.actions.map( ( a ) => a.id as AccessActionKey ),
        } ),
      );

      this.originalSelectionOfAccess = {
        role,
        permissions,
      };
    } catch ( error ) {
      console.error( error );
      this.originalSelectionOfAccess = null;
    }
  }


  /**
   * Helper: check if a module is currently selected in originalSelectionOfAccess.
   * Used by template:
   *   [checked]="hasModel(mainItem.module)"
   */
  protected hasModel( model: string ): boolean {
    if ( !this.originalSelectionOfAccess ) return false;

    return this.originalSelectionOfAccess.permissions.some(
      ( p ) => p.module.toLowerCase() === model.toLowerCase(),
    );
  }


  /**
   * Helper: check if a concrete action (by id) is selected under a module.
   * Used by template:
   *   [checked]="hasAccess(subItem.id, mainItem.module)"
   */
  protected hasAccess( accessId: string, model: string ): boolean {
    if ( !this.originalSelectionOfAccess ) return false;

    const perm = this.originalSelectionOfAccess.permissions.find(
      ( p ) => p.module.toLowerCase() === model.toLowerCase(),
    );
    if ( !perm ) return false;

    return perm.actions.some(
      ( a ) => a.toLowerCase() === accessId.toLowerCase(),
    );
  }

  /**
   * 2) When a single action checkbox is toggled.
   *    - We:
   *        • validate role
   *        • look up canonical module + action from allPermissionAccesses
   *        • add/remove that action id from originalSelectionOfAccess
   *    - If after removal, module has 0 actions, we also remove the module
   *      (so the parent module checkbox will become unchecked).
   */
  protected toggleAccess(
    isChecked: boolean,
    module: string,
    actionId: string, // this is subItem.id from template
  ): void {
    const safeRole = this.role as Role | undefined;
    if ( !safeRole || !DEFAULT_ROLES.includes( safeRole ) ) {
      return;
    }

    // Find canonical module definition
    const moduleDef = this.allPermissionAccesses.find(
      ( m ) => m.module.toLowerCase() === module.toLowerCase(),
    );
    if ( !moduleDef ) return;

    // Find canonical action definition
    const actionDef = moduleDef.actions.find(
      ( a ) => a.id.toLowerCase() === actionId.toLowerCase(),
    );
    if ( !actionDef ) return;

    // Lazily initialise our selection map if needed
    if (
      !this.originalSelectionOfAccess ||
      this.originalSelectionOfAccess.role !== safeRole
    ) {
      this.originalSelectionOfAccess = {
        role: safeRole,
        permissions: [],
      };
    }

    const perms = this.originalSelectionOfAccess.permissions;

    // Find or create the module entry
    let moduleEntry = perms.find(
      ( p ) =>
        p.module.toLowerCase() === moduleDef.module.toLowerCase(),
    );

    if ( !moduleEntry ) {
      moduleEntry = {
        module: moduleDef.module as AccessModuleKey,
        actions: [],
      };
      perms.push( moduleEntry );
    }

    const actionKey = actionDef.id as AccessActionKey;

    if ( isChecked ) {
      // Add canonical action id if missing
      if ( !moduleEntry.actions.includes( actionKey ) ) {
        moduleEntry.actions.push( actionKey );
      }
    } else {
      // Remove the action id
      const idx = moduleEntry.actions.indexOf( actionKey );
      if ( idx !== -1 ) {
        moduleEntry.actions.splice( idx, 1 );
      }

      // If no actions left → remove module entry
      if ( moduleEntry.actions.length === 0 ) {
        const mIdx = perms.indexOf( moduleEntry );
        if ( mIdx !== -1 ) {
          perms.splice( mIdx, 1 );
        }
      }
    }
  }


  /**
   * 3) When the module “select all” checkbox is toggled.
   *    - If checked → all actions in that module are selected
   *    - If unchecked → whole module removed
   */
  protected toggleModule(
    isChecked: boolean,
    module: string,
  ): void {
    const safeRole = this.role as Role | undefined;
    if ( !safeRole || !DEFAULT_ROLES.includes( safeRole ) ) {
      return;
    }

    // Find canonical module definition
    const moduleDef = this.allPermissionAccesses.find(
      ( m ) => m.module.toLowerCase() === module.toLowerCase(),
    );
    if ( !moduleDef ) return;

    // Lazily initialise selection map
    if (
      !this.originalSelectionOfAccess ||
      this.originalSelectionOfAccess.role !== safeRole
    ) {
      this.originalSelectionOfAccess = {
        role: safeRole,
        permissions: [],
      };
    }

    const perms = this.originalSelectionOfAccess.permissions;
    const idx = perms.findIndex(
      ( p ) => p.module.toLowerCase() === moduleDef.module.toLowerCase(),
    );

    if ( isChecked ) {
      // All canonical action ids for this module
      const allActionIds: AccessActionKey[] = moduleDef.actions.map(
        ( a ) => a.id as AccessActionKey,
      );

      if ( idx === -1 ) {
        perms.push( {
          module: moduleDef.module as AccessModuleKey,
          actions: allActionIds,
        } );
      } else {
        perms[ idx ].actions = allActionIds;
      }
    } else {
      // Remove entire module from permissions
      if ( idx !== -1 ) {
        perms.splice( idx, 1 );
      }
    }
  }


  /**
   * Getter used by insertNewUser().
   * If nothing was selected yet, returns an empty map for the current role.
   */
  protected getRoleAccessPayload(): ROLE_ACCESS_MAP {
    const safeRole = this.role as Role;

    if ( this.originalSelectionOfAccess && this.originalSelectionOfAccess.role === safeRole ) {
      return this.originalSelectionOfAccess;
    }

    return {
      role: safeRole,
      permissions: [],
    };
  }


  // ──────────────────────────────────────────────────────────────────────────
  // Update user (method name kept as insertNewUser for template)
  // ──────────────────────────────────────────────────────────────────────────
  protected async updateUser(): Promise<void> {
    let isSuccess = false;
    try {
      const verifyEmail: object =
        await this.crypto.generateEmailVerificationToken();
      const now = new Date();
      const oneMonth = new Date(
        new Date( now.setMonth( now.getMonth() + 1 ) ).getTime(),
      );

      if ( !this.phoneCode ) {
        throw new Error( 'Phone code is required!' );
      }

      if ( !this.phone ) {
        throw new Error( 'Phone number is required!' );
      }

      this.phoneNumber = {
        code: this.phoneCode,
        number: this.phone
      };


      // required fields
      if ( !this.fullname )
        throw new Error( 'User full name is required' );

      if ( !this.userGender )
        throw new Error( 'User gender is required' );

      if ( !this.email )
        throw new Error( 'User email is required' );

      if ( !this.phoneNumber )
        throw new Error( 'User contact number details is required' );

      if ( !this.houseNumber )
        throw new Error( 'User house number is required' );

      if ( !this.street )
        throw new Error( 'User street is required' );
      if ( !this.city )

        throw new Error( 'User city is required' );

      if ( !this.postcode )
        throw new Error( 'User postcode is required' );

      if ( !this.countryControl.value )
        throw new Error( 'User country is required' );

      if ( !this.dateOfBirth )
        throw new Error( 'User date of birth is required' );

      if ( !this.age )
        throw new Error( 'User age is required' );

      if ( !this.isValidAge )
        throw new Error( 'User age is not valid' );

      if ( this.isActive === null || this.isActive === undefined ) {
        throw new Error( 'User active status is required!' );
      }
      if ( !this.userBio )
        throw new Error( 'User bio is required!' );

      if ( !this.nationality ) {
        throw new Error( 'User nationality is required!' );
      }
      if ( !this.nicOrPassport ) {
        throw new Error( 'User identity number is required!' );
      }

      if ( !this.role )
        throw new Error( 'User role is required' );

      const roleAccess = this.getRoleAccessPayload();
      if ( !roleAccess || !roleAccess.permissions.length ) {
        throw new Error( 'User access is required' );
      }

      if ( this.isEmailError ) {
        throw new Error( this.emailErrorMessage );
      }

      if ( this.isPhoneError ) {
        throw new Error( this.phoneErrorMessage );
      }

      if ( this.isUsernameExist ) {
        throw new Error( 'Username already exist' );
      }

      const trimmedPassword = this.password.trim();
      if ( trimmedPassword ) {
        if ( !this.strongPasswordPattern.test( trimmedPassword ) ) {
          throw new Error( 'Password does not match the required strength pattern' );
        }
      }

      if ( !this.usernameMatchPattern ) {
        throw new Error( 'Username does not match the pattern' );
      }

      // Build formdata
      const formData: FormData = new FormData();
      this.progress.start();

      formData.append( 'username', this.username.trim() );
      if ( trimmedPassword ) {
        formData.append( 'password', trimmedPassword );
      }
      formData.append( 'name', this.fullname.trim() );
      formData.append( 'email', this.email.trim() );
      formData.append( 'oldEmail', this.oldEmail.trim() );
      formData.append(
        'dateOfBirth',
        this.dateOfBirth.toISOString().trim(),
      );
      formData.append( 'age', this.age.toString().trim() );
      formData.append(
        'gender',
        this.userGender.toLowerCase().trim(),
      );
      formData.append( 'bio', this.userBio.trim() );
      formData.append( 'nationality', this.nationality.trim() );
      formData.append( 'nicOrPassport', this.nicOrPassport.trim() );
      formData.append( 'phoneNumber', JSON.stringify( this.phoneNumber ) );

      if ( this.userimage ) {
        formData.append( 'userimage', this.userimage, `${ this.username }_image.png` );
      }

      formData.append( 'role', this.role );
      formData.append( 'isActive', this.isActive.toString() );
      formData.append( 'street', this.street.trim() );
      formData.append(
        'houseNumber',
        this.houseNumber.toString().trim(),
      );
      formData.append( 'city', this.city.trim() );
      formData.append(
        'stateOrProvince',
        this.stateOrProvince.trim(),
      );
      formData.append( 'postcode', this.postcode.toString().trim() );

      const countryValue = this.countryControl.value ?? '';
      formData.append( 'country', countryValue.trim() );

      formData.append(
        'access',
        JSON.stringify( roleAccess ).trim(),
      );
      formData.append(
        'otpToken',
        JSON.stringify( verifyEmail ).trim(),
      );
      formData.append(
        'otpValidTime',
        JSON.stringify( { otpValidTime: oneMonth } ),
      );
      const multiAuthEnabled: string =
        this.user && this.user.multiAuthEnabled ? 'true' : 'false';
      formData.append( 'multiAuthEnabled', multiAuthEnabled );
      formData.append( 'updatedAt', this.updatedAt.toString() );
      formData.append( 'creator', this.creator );
      formData.append( 'updator', this.updator );

      const res = await this.apiService.updateUser(
        formData,
        this.username,
      );

      if ( !res.success || res.status !== 'success' ) {
        throw new Error( 'Failed to update user!' );
      }

      this.notification.notification( res.status, res.message );
      isSuccess = true;

    }
    catch ( error ) {
      console.error( error );
      let message = 'Unexpected error occurred while updating user!';

      if ( error instanceof HttpErrorResponse ) {
        message = error.error?.message ?? message;
      } else if ( error instanceof Error ) {
        message = error.message || message;
      }

      this.notification.notification( 'error', message );
    }
    finally {
      this.progress.complete();

      if ( isSuccess ) {
        this.navigationTimeoutId = window.setTimeout( async (): Promise<void> => {
          try {
            if ( !this.user ) {
              await this.router.navigate( [ '/dashboard/users' ] );
              return;
            }

            if ( this.user.username !== this.username ) {
              await this.authService.clearCredentials();
              await this.router.navigate( [ '/login' ] );
              return;
            }

            await this.router.navigate( [ '/dashboard/users' ] );
            return;

          } catch ( error ) {
            console.error( '[Error]: delayed navigation after updateUser failed\n', error, '\n' );
            return;
          } finally {
            if ( this.navigationTimeoutId !== null ) {
              window.clearTimeout( this.navigationTimeoutId );
              this.navigationTimeoutId = null;
            }
          }
        }, 1000 );
      }
    }


  }
}
