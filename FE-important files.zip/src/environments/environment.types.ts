export interface Environment {
  /** Is this a production build? */
  production: boolean;

  /** Frontend origin (what backend expects in CORS / FRONTEND_ORIGIN). */
  frontendOrigin: string;

  /** HTTP API base (matches backend apiOrigin / HOST:PORT). */
  apiOrigin: string;

  /** Base URL for file previews/downloads (points to STORAGE_ROOT). */
  filesBaseUrl: string;

  /** Is this build running inside Electron shell? */
  electron: boolean;

  /** Optional WebSocket base (usually same as apiOrigin). */
  wsOrigin: string;

  /** For internal links or meta tags within the Angular app. */
  localRoot: string;
}
