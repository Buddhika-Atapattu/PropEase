import { Injectable } from '@angular/core';
import { Router, NavigationStart, UrlTree } from '@angular/router';
import { AuthService } from '../auth/auth.service';
import { filter } from 'rxjs/operators';
import { parsePhoneNumberFromString } from 'libphonenumber-js';
import { firstValueFrom } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { MSG } from '../../types/api-message.types';
import { environment } from '../../../environments/environment';
import type { User } from '../APIs/apis.service';



@Injectable( {
  providedIn: 'root',
} )
export class UserControllerService {
  private readonly root: string = ( environment.apiOrigin ?? 'http://localhost:3000' ).replace( /\/+$/, '' );;
  constructor (
    private router: Router,
    private authService: AuthService,
    private http: HttpClient
  ) {}

  public isPhoneNumberValid( data: User[ 'phoneNumber' ] | string ): boolean {

    let fullPhoneNumber: string = '';
    if ( typeof data === 'string' ) {
      fullPhoneNumber = data;
    }
    else if ( typeof data === 'object' ) {
      fullPhoneNumber = data.code.code + data.number;
    }
    else {
      return false;
    }

    const phoneNumber = parsePhoneNumberFromString( fullPhoneNumber.trim() );
    return phoneNumber?.isValid() ?? false;
  }

  //<================================================================ API ================================================================>
  public async emailValidator( email: string ): Promise<MSG> {
    return await firstValueFrom(
      this.http.get<MSG>(
        `${ this.root }/api-validator/email-validator/:${ email }`
      )
    );
  }

  public async convertToPDF( fileUrl: string ): Promise<Blob> {
    return await firstValueFrom(
      this.http.post( `${ this.root }/api-file-transfer/convert-to-pdf`,
        { fileUrl },
        { responseType: 'blob' } // Important: expect binary PDF data
      )
    );
  }
  //<================================================================ END API ================================================================>
}
