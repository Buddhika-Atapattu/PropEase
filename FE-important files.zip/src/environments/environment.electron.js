"use strict";
// Path: src/environments/environment.electron.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.environment = void 0;
exports.environment = {
    // Electron build is considered "production" from Angular’s POV
    production: true,
    frontendOrigin: 'http://localhost:4200',
    /**
     * Local Angular origin used in dev-Electron hybrid mode.
     * - When you run Angular dev-server + Electron wrapper.
     */
    localRoot: 'http://localhost:4200',
    /**
     * Backend API for Electron.
     * - Typically your local Node/Express running on 3000
     * - Electron talks to this like a regular browser client.
     */
    apiOrigin: 'http://localhost:3000',
    /**
     * WebSocket / Socket.IO base.
     * - If your SocketService uses `apiOrigin` directly, you can omit this.
     * - If you follow the prod pattern I gave earlier, keep this.
     */
    wsOrigin: 'http://localhost:3000',
    /**
     * Base URL for media/files served by backend.
     * - Using explicit path here avoids depending on a fallback helper.
     */
    filesBaseUrl: 'http://localhost:3000/uploads/',
    /**
     * Flag so the app can do small Electron-specific tweaks
     * (native menus, window controls, different routing, etc.)
     */
    electron: true,
};
