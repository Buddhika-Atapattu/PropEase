// Path: src/app/pages/team-management/home/home.component.ts
// ============================================================================
// Team Management - Home (All Teams Table) - FIXED (BE/FE aligned)
// ----------------------------------------------------------------------------
// Key fixes:
//  - Use TeamManagementDto type from service (matches backend TeamManagementBase)
//  - teamId comes from teamCode (NOT Mongo _id)
//  - teamLogo is optional (fallback instead of throw)
//  - captain user info is optional (fallback to captain.username)
//  - extract teams array from common ApiResponseBuilder shapes (no hard-coded system.teams)
//  - safe totals: 0 is valid, no falsey checks
//  - safe pagination: safeIndex uses totalPages, safeLimit uses totalItems
//  - no duplicate loads via setter edge; keep your pattern but stable
// ============================================================================

// Angular
import { Component, ViewChild, OnInit, type OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

// Material UI
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatIconModule } from '@angular/material/icon';

// HTTP
import { HttpErrorResponse } from '@angular/common/http';

// Services
import type { TeamDomain, TeamManagementDto, TaskStatus } from '../../../services/teamManagementService/team-management.service';
import { DEFAULT_TEAM_DOMAINS, TeamManagementService } from '../../../services/teamManagementService/team-management.service';
import { APIsService } from '../../../services/APIs/apis.service';
import { PaginationUtil } from '../../../source/utility/pagination.utils';

// Components
import {
  CustomTableComponent,
  TableButton,
  TableColumn,
  TableUiButton,
  TableUiButtonClickConfig,
} from '../../../components/shared/custom-table/custom-table.component';
import { NotificationDialogComponent } from '../../../components/dialogs/notificationBar/notificationBar.component';

interface AllTeamData {
  teamLogo: string;
  teamId: string;
  teamName: string;
  teamTotal: number;

  captainImage: string;
  captainName: string;

  domain: TeamDomain;
  assignedTasks: number;
  completedTasks: number;

  viewButton: TableButton;
  editButton: TableButton;
}

@Component( {
  selector: 'app-team-management-home',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    MatTooltipModule,
    NotificationDialogComponent,
    CustomTableComponent,
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
} )
export class HomeComponent implements OnInit, OnDestroy {

  @ViewChild( NotificationDialogComponent, { static: true } )
  public notificationDialog!: NotificationDialogComponent;

  // ─────────────────────────────────────────────────────────────
  // Table state (private backing fields)
  // ─────────────────────────────────────────────────────────────
  private _allTeamIsLoading: boolean = false;
  private _allTeamIndex: number = 0;
  private _allTeamLimit: number = 5;
  private _allTeamSearch: string = '';

  // Prevent duplicate load calls
  private _allTeamLoadInFlight: boolean = false;

  // ─────────────────────────────────────────────────────────────
  // Public UI bindings
  // ─────────────────────────────────────────────────────────────
  protected allTeamTableTitle: string = 'All teams';
  protected allTeamTotal: number = 0;

  private readonly allTeamActionButtons: ReadonlyArray<TableUiButton> = [
    { id: 'team.assignTask', iconKey: 'task.assign', label: 'Assign Task', tooltip: 'Assign Task', tone: 'good' },
    { id: 'team.view', iconKey: 'view', label: 'View', tooltip: 'View Team', tone: 'normal' },
    { id: 'team.edit', iconKey: 'edit', label: 'Edit', tooltip: 'Edit Team', tone: 'normal' },
  ] as const;

  protected allTeamTableColumns: TableColumn[] = [
    { key: 'teamLogo', label: 'Team Logo' },
    { key: 'teamId', label: 'Team ID' },
    { key: 'teamName', label: 'Team Name' },
    { key: 'teamTotal', label: 'Team Total' },
    { key: 'captainImage', label: 'Captain' },
    { key: 'captainName', label: 'Captain Name' },
    { key: 'domain', label: 'Team Domain' },
    { key: 'assignedTasks', label: 'Total Assigned Tasks' },
    { key: 'completedTasks', label: 'Total Completed Tasks' },
    {
      key: 'assignTaskAction',
      label: 'Assign Task',
      render: 'multipleActions',
      multipleActions: [ this.allTeamActionButtons[ 0 ] ],
    },
    {
      key: 'viewTeamAction',
      label: 'View Team',
      render: 'multipleActions',
      multipleActions: [ this.allTeamActionButtons[ 1 ] ],
    },
    {
      key: 'editTeamAction',
      label: 'Edit Team',
      render: 'multipleActions',
      multipleActions: [ this.allTeamActionButtons[ 2 ] ],
    },
  ];

  protected allTeamTableData: AllTeamData[] = [];

  // ─────────────────────────────────────────────────────────────
  // Getters / setters (paginator bindings)
  // ─────────────────────────────────────────────────────────────

  public get allTeamIsLoading(): boolean {
    return this._allTeamIsLoading;
  }

  public set allTeamIsLoading( value: boolean ) {
    const next = !!value;
    const isRisingEdge = !this._allTeamIsLoading && next;

    this._allTeamIsLoading = next;

    // Only trigger on "reload request" edge
    if ( !isRisingEdge ) return;

    if ( this._allTeamLoadInFlight ) return;
    this._allTeamLoadInFlight = true;

    void this.allTeamLoadInit( this._allTeamIndex, this._allTeamLimit, this._allTeamSearch )
      .finally( () => {
        this._allTeamLoadInFlight = false;
        this._allTeamIsLoading = false;
      } );
  }

  public get allTeamIndex(): number {
    return this._allTeamIndex;
  }
  public set allTeamIndex( value: number ) {
    this._allTeamIndex = value;
    void this.allTeamLoadInit( this._allTeamIndex, this._allTeamLimit, this._allTeamSearch );
  }

  public get allTeamLimit(): number {
    return this._allTeamLimit;
  }
  public set allTeamLimit( value: number ) {
    this._allTeamLimit = value;
    void this.allTeamLoadInit( this._allTeamIndex, this._allTeamLimit, this._allTeamSearch );
  }

  public get allTeamSearch(): string {
    return this._allTeamSearch;
  }
  public set allTeamSearch( value: string ) {
    this._allTeamSearch = String( value ?? '' ).trim();
    void this.allTeamLoadInit( this._allTeamIndex, this._allTeamLimit, this._allTeamSearch );
  }

  public constructor (
    private readonly router: Router,
    private readonly teamService: TeamManagementService,
    private readonly apiService: APIsService,
  ) {}

  // ─────────────────────────────────────────────────────────────
  // Lifecycle
  // ─────────────────────────────────────────────────────────────
  public async ngOnInit(): Promise<void> {
    await this.allTeamLoadInit( this._allTeamIndex, this._allTeamLimit, this._allTeamSearch );
  }

  public ngOnDestroy(): void {
    // reserved
  }

  // ─────────────────────────────────────────────────────────────
  // UI actions
  // ─────────────────────────────────────────────────────────────
  protected async createTeamRouter(): Promise<boolean> {
    return await this.router.navigate( [ '/dashboard/team-management/create' ] );
  }

  protected async allTeamActionButtonCentra( value: TableUiButtonClickConfig ): Promise<void> {
    try {
      if ( !value ) throw new Error( 'Invalid button event data!' );

      const id = String( value.id ?? '' ).trim();
      const teamID = String( value.row?.teamId ?? '' ).trim(); //  teamId = teamCode
      if ( !teamID ) throw new Error( 'Invalid team ID!' );

      switch ( id ) {
        case 'team.assignTask':
          await this.router.navigate( [ '/dashboard/team-management/asign-task', teamID ] );
          return;

        case 'team.view':
          await this.router.navigate( [ '/dashboard/team-management/view', teamID ] );
          return;

        case 'team.edit':
          await this.router.navigate( [ '/dashboard/team-management/edit', teamID ] );
          return;

        default:
          return;
      }
    } catch ( error ) {
      // eslint-disable-next-line no-console
      console.error( '[Error:] [TeamHome] action handler failed.\n', error );
    }
  }

  protected async fetchAllTeamTableData(): Promise<void> {
    await this.allTeamLoadInit( this._allTeamIndex, this._allTeamLimit, this._allTeamSearch );
  }

  // ─────────────────────────────────────────────────────────────
  // Data loading
  // ─────────────────────────────────────────────────────────────
  private async allTeamLoadInit( index: number, limit: number, search?: string ): Promise<void> {
    try {
      this._allTeamIsLoading = true;
      this.allTeamTableData = [];

      // 1) Totals
      const totalRes = await this.teamService.getTeamTotals();
      if ( !totalRes.success ) throw new Error( totalRes.message ?? 'Failed to fetch total number of teams!' );

      const rawTotal = this.apiService.extractNumberFromOther( totalRes.data, 'totalTeams' );


      //  allow 0
      if ( rawTotal === null || rawTotal === undefined ) throw new Error( 'Invalid total number of teams!' );
      if ( !Number.isFinite( rawTotal ) || !Number.isInteger( rawTotal ) || rawTotal < 0 ) {
        throw new Error( 'Invalid data format of total number of teams!' );
      }

      const totalItems = rawTotal;
      this.allTeamTotal = totalItems;

      // 2) Pagination safety
      const safeLimit = PaginationUtil.safeLimit( limit, totalItems );
      const totalPages = Math.max( 1, Math.ceil( totalItems / safeLimit ) );
      const safeIndex = PaginationUtil.safeIndex( index, totalPages );

      const safeSearch = typeof search === 'string' && search.trim() ? search.trim() : undefined;

      // 3) Fetch teams
      const res = await this.teamService.getTeams( safeIndex, safeLimit, safeSearch );

      if ( !res.success ) throw new Error( res.message ?? 'Failed to fetch team data!' );



      //  extract teams array from common shapes (no hard-coded system.teams)
      const rawTeams = this.pickTeamsArray( res.data );
      if ( !Array.isArray( rawTeams ) ) throw new Error( 'Invalid array of team data!' );

      const tableData: AllTeamData[] = [];
      for ( const team of rawTeams ) {
        try {
          tableData.push( this.buildAllTeamTableRow( team ) );
        } catch ( rowErr ) {
          // eslint-disable-next-line no-console
          console.warn( '[Warning:] [TeamHome] Skipping invalid team row.\n', rowErr );
        }
      }

      this.allTeamTableData = [ ...tableData ];
      return;

    } catch ( error ) {
      // eslint-disable-next-line no-console
      console.error( '[Error:] [TeamHome] Failed to load teams.\n', error );

      let message = 'Unexpected error occured!';
      if ( error instanceof HttpErrorResponse ) {
        message = error.error?.message ?? message;
      } else if ( error instanceof Error ) {
        message = error.message;
      }

      this.notificationDialog.notification( 'error', message );
      return;

    } finally {
      setTimeout( () => {
        this._allTeamIsLoading = false;
      }, 250 );
    }
  }

  /**
   * Extract teams array from whatever ApiResponseBuilder shape you use.
   * Supports:
   *  - data.other.teams
   *  - data.teams
   *  - data.system.teams (your old one)
   *  - data.other.data.teams (nested)
   */
  private pickTeamsArray( data: any ): TeamManagementDto[] {
    const d = data as any;
    return (
      d?.other?.teams ??
      d?.teams ??
      d?.system?.teams ??
      d?.other?.data?.teams ??
      []
    ) as TeamManagementDto[];
  }

  // ─────────────────────────────────────────────────────────────
  // Row builder (BE aligned + safe fallbacks)
  // ─────────────────────────────────────────────────────────────
  private buildAllTeamTableRow( data: TeamManagementDto ): AllTeamData {
    //  logo is optional in BE; fallback to definedImage logic of table
    const teamLogo: string = String( data.teamLogo?.url ?? '' ).trim() || '';

    //  FE uses teamCode as "teamId"
    const teamId: string = String( data.teamCode ?? '' ).trim();
    if ( !teamId ) throw new Error( 'Invalid team id!' );

    const teamName: string = String( data.teamName ?? '' ).trim();
    if ( !teamName ) throw new Error( 'Invalid team name!' );

    const teamTotal: number = Number( data.memberTotal );
    if ( !Number.isFinite( teamTotal ) || !Number.isInteger( teamTotal ) || teamTotal < 0 ) {
      throw new Error( 'Invalid total number of members!' );
    }

    // captain.user is optional; fallback to username
    const captainImage: string = String( ( data.captain as any )?.user?.image ?? '' ).trim() || '';
    const captainName: string =
      String( ( data.captain as any )?.user?.name ?? '' ).trim() ||
      String( data.captain?.username ?? '' ).trim();

    if ( !captainName ) throw new Error( 'Invalid captain name!' );

    const domain: TeamDomain = data.domain as TeamDomain;
    if ( !domain || !DEFAULT_TEAM_DOMAINS.includes( domain ) ) {
      throw new Error( 'Invalid team domain!' );
    }

    const taskArray = Array.isArray( data.assignTasks ) ? data.assignTasks : [];
    const assignedTasks: number = taskArray.length;

    const completedTasks: number = taskArray.reduce( ( total: number, task ) => {
      const st = String( ( task as any )?.status ?? '' ).toLowerCase() as TaskStatus;
      return st === 'completed' ? total + 1 : total;
    }, 0 );

    const viewButton: TableButton = { action: 'view', icon: 'visibility', label: 'View Team' };
    const editButton: TableButton = { action: 'edit', icon: 'edit', label: 'Edit Team' };

    return {
      teamLogo,
      teamId,
      teamName,
      teamTotal,
      captainImage,
      captainName,
      domain,
      assignedTasks,
      completedTasks,
      viewButton,
      editButton,
    };
  }
}
